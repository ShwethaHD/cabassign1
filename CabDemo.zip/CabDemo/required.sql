CREATE TABLE cab (cabid NUMBER PRIMARY KEY, name VARCHAR2 (20), pincode VARCHAR2(6),cab_number varchar2(15));

INSERT INTO cab VALUES(1001,'Tata Indica','600157','MH-12 BG3344');
INSERT INTO cab VALUES(1002,'Mahindra','688157','Up-18 SS 8765');
INSERT INTO cab VALUES(1003,�Hyundai Xcent�,'612157','TN-23 XY 1234');
//TO DO � INSERT few more mobile details.

CREATE TABLE cab_request(request_id NUMBER,customer_name vARCHAR2(20),phone_number varchar2(10),date_of_request DATE,request_status varchar2(12),cab_number varchar2(15),address_of_pickup VARCHAR2(30),
, pin_code varchar2(6));

CREATE SEQUENCE customer_sequence
START WITH 1;