package com.capgemini.cab.service;


import com.capgemini.cab.bean.CustomerBean;
import com.capgemini.cab.exception.CabException;

public interface IServiceCab {
public boolean addCustomer(CustomerBean customerBean)throws CabException;
public int getRequestId();
public String bookCab(int requestId)throws CabException;




}