package com.capgemini.cab.bean;

import java.time.LocalDate;

public class CustomerBean {
	private int requestId;
	private String customer_name;
	private String phone_number;
	private String cab_number;
	private String address_of_pickup;
	private String pincode;
	private LocalDate Date_of_request;
	public CustomerBean() {
		super();
	}
	public CustomerBean(String customer_name, String phone_number,
			String cab_number, String address_of_pickup, String pincode,
			LocalDate date_of_request) {
		super();
		this.customer_name = customer_name;
		this.phone_number = phone_number;
		this.cab_number = cab_number;
		this.address_of_pickup = address_of_pickup;
		this.pincode = pincode;
		Date_of_request = date_of_request;
	}
	public int getRequestId() {
		return requestId;
	}
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}
	public String getCab_number() {
		return cab_number;
	}
	public void setCab_number(String cab_number) {
		this.cab_number = cab_number;
	}
	public String getAddress_of_pickup() {
		return address_of_pickup;
	}
	public void setAddress_of_pickup(String address_of_pickup) {
		this.address_of_pickup = address_of_pickup;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public LocalDate getDate_of_request() {
		return Date_of_request;
	}
	public void setDate_of_request(LocalDate date_of_request) {
		Date_of_request = date_of_request;
	}
	@Override
	public String toString() {
		return "CustomerBean [requestId=" + requestId + ", customer_name="
				+ customer_name + ", phone_number=" + phone_number
				+ ", cab_number=" + cab_number + ", address_of_pickup="
				+ address_of_pickup + ", pincode=" + pincode
				+ ", Date_of_request=" + Date_of_request + "]";
	}
	
}