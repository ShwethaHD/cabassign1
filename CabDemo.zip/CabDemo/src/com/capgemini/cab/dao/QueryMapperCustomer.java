package com.capgemini.cab.dao;

public interface QueryMapperCustomer {
	public static final  String INSERT_CABREQUEST = "INSERT INTO cab_request VALUES(seq_request_id.NEXTVAL,?,?,?,'Not Booked',NULL,?,?)";
	
	public static final  String UPDATE_CABREQUEST = "UPDATE cab_request SET request_status='Booked', cab_number=? WHERE request_id=? )";
	
	public static final String VIEW_CABS = "SELECT cab_number FROM cab WHERE pincode=?";
	
	public static final String VIEW_PINCODE = "SELECT pincode FROM cab_request WHERE request_id=?";
	
	public static final String SHOW_ID = "SELECT seq_request_id.CURRVAL FROM DUAL";
	
}
